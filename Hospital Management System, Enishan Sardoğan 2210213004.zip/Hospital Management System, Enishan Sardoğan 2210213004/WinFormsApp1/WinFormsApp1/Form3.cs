﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

          private void button2_Click(object sender, EventArgs e)
        {

            string patientName = textBox1.Text.Trim();
            string patientDisease = textBox2.Text.Trim();
            string patientFee = textBox3.Text.Trim();

                   if (string.IsNullOrEmpty(patientName) || string.IsNullOrEmpty(patientDisease) || string.IsNullOrEmpty(patientFee))
            {
                MessageBox.Show("You need to full all areas!");
                return;
            }

               if (!decimal.TryParse(patientFee, out _))
            {
                MessageBox.Show("Fee must be a numeric value!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            try
            {
                using (SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\databaseforproject\\databaseproject.db;Version=3;Pooling=False"))
                {
                    connection.Open();



                    using (var transaction = connection.BeginTransaction())
                    {



                          string query = "INSERT INTO Patients (Name, Disease, Fee) VALUES (@Name, @Disease, @Fee)";
                        using (SQLiteCommand command = new SQLiteCommand(query, connection))
                        {   
                            command.Parameters.AddWithValue("@Name", patientName);
                            command.Parameters.AddWithValue("@Disease", patientDisease);
                            command.Parameters.AddWithValue("@Fee", patientFee);
                            command.ExecuteNonQuery();
                            MessageBox.Show("Patient saved successfully!");
                        }

                        transaction.Commit();
                        connection.Close();
                    }

                    connection.Close();


                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("An error occured: " + ex.Message);
            }




        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string patientNameToDelete = textBox4.Text.Trim();

                   if (string.IsNullOrEmpty(patientNameToDelete))
            {
                MessageBox.Show("Please enter the name of the patient to delete!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\databaseforproject\\databaseproject.db;Version=3;Pooling=False"))
                {
                    connection.Open();

                    string selectQuery = "SELECT * FROM Patients WHERE Name = @Name";
                    using (SQLiteCommand selectCommand = new SQLiteCommand(selectQuery, connection))
                    {
                        selectCommand.Parameters.AddWithValue("@Name", patientNameToDelete);

                        using (SQLiteDataReader reader = selectCommand.ExecuteReader())
                        {

                            if (!reader.HasRows)
                            {
                                MessageBox.Show("Patient not found in the database!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                return;
                            }
                        }

  
                    }
                    string deleteQuery = "DELETE FROM Patients WHERE Name = @Name";
                    using (SQLiteCommand deleteCommand = new SQLiteCommand(deleteQuery, connection))
                    {
                        deleteCommand.Parameters.AddWithValue("@Name", patientNameToDelete);
                        deleteCommand.ExecuteNonQuery();
                        MessageBox.Show("Patient deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    connection.Close();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
