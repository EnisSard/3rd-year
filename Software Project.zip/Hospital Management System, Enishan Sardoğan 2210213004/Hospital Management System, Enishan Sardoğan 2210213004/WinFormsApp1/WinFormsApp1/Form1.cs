namespace WinFormsApp1;
using System;
using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;




public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
        CreateDatabase(); 

    }



    private void CreateDatabase()
    {
      
        string connectionString = "Data Source=C:\\databaseforproject\\databaseproject.db;Version=3;";

  
        {
     
            using (SQLiteConnection connection = new SQLiteConnection(connectionString))
            {
                connection.Open();


                          string createTableQuery = @"
                        CREATE TABLE IF NOT EXISTS Users (
                            Id INTEGER PRIMARY KEY AUTOINCREMENT,
                            Username TEXT NOT NULL UNIQUE,
                            Password TEXT NOT NULL
                        );";

                using (SQLiteCommand command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }



                string createPatientsTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Patients (
                     Id INTEGER PRIMARY KEY AUTOINCREMENT,
                     Name TEXT NOT NULL,
                     Disease TEXT NOT NULL,
                     Fee INTEGER NOT NULL
                      );";
                using (SQLiteCommand command = new SQLiteCommand(createPatientsTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }



                connection.Close();
            }
        }
    }





    private void label1_Click(object sender, EventArgs e)
    {

    }


    private void button1_Click(object sender, EventArgs e)
    {
        string username = textBox1.Text.Trim();
        string password = textBox2.Text.Trim();


 
        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
        {
            MessageBox.Show("Username or Password can't be empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        try
        {
            using (SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\databaseforproject\\databaseproject.db;Version=3;"))
            {
                connection.Open();


                string insertQuery = "INSERT INTO Users (Username, Password) VALUES (@Username, @Password)";
                using (SQLiteCommand command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    command.ExecuteNonQuery();
                    MessageBox.Show("Register Successful!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                connection.Close();
            }
        }

        catch (Exception ex)
        {
            MessageBox.Show("An error occured: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }








    private void textBox1_TextChanged_1(object sender, EventArgs e)
    {

    }

    private void textBox2_TextChanged(object sender, EventArgs e)
    {

    }



    private void textBox3_TextChanged(object sender, EventArgs e)
    {

    }

    private void textBox4_TextChanged(object sender, EventArgs e)
    {

    }



    private void loginenter_Click(object sender, EventArgs e)
    {

        string username = textBox3.Text.Trim();
        string password = textBox4.Text.Trim();

        if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
        {
            MessageBox.Show("Username or Password can't be empty!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }


        try
        {
            using (SQLiteConnection connection = new SQLiteConnection("Data Source=C:\\databaseforproject\\databaseproject.db;Version=3;"))
            {
                connection.Open();

                string selectQuery = "SELECT * FROM Users WHERE Username = @Username AND Password = @Password";

                using (SQLiteCommand command = new SQLiteCommand(selectQuery, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password); 
                    SQLiteDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        MessageBox.Show("Login Successful!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        Form2 form2 = new Form2();
                        form2.Show();
                        this.Hide();

                        reader.Close();
                        command.Dispose();
                        connection.Close();



                    }
                    else
                    {
 
                        reader.Close();
                        command.Dispose();
                        connection.Close();

                        MessageBox.Show("Wrong username or password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }



                connection.Close();
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("There is an error occured: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void label4_Click(object sender, EventArgs e)
    {

    }
}





