﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace WinFormsApp1
{
    public partial class Form4 : Form
    {
        private SQLiteConnection sqliteConnection;

        public Form4()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            CreateTableIfNotExists();
        }

        private void InitializeDatabaseConnection()
        {
            string connectionString = "Data Source=appointments.db;Version=3;";
            sqliteConnection = new SQLiteConnection(connectionString);
            sqliteConnection.Open();
        }

        private void CreateTableIfNotExists()
        {
            string sql = @"
                CREATE TABLE IF NOT EXISTS Appointments (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Name TEXT NOT NULL,
                    Time REAL NOT NULL
                );";

            using (var cmd = new SQLiteCommand(sql, sqliteConnection))
            {
                cmd.ExecuteNonQuery();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();           // Hide Form4
            Form2 form2 = new Form2(); // Create a new instance of Form2
            form2.Show();          // Show Form2
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string inputTime = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(inputTime))
            {
                MessageBox.Show("Please enter a time.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!double.TryParse(inputTime.Replace(":", "."), out double parsedTime))
            {
                MessageBox.Show("Please enter a valid time (e.g., 16.5 for 16:30).", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = "SELECT COUNT(*) FROM Appointments WHERE Time = @time";

            using (var cmd = new SQLiteCommand(sql, sqliteConnection))
            {
                cmd.Parameters.AddWithValue("@time", parsedTime);
                long count = (long)cmd.ExecuteScalar();

                if (count > 0)
                {
                    MessageBox.Show("This time is already taken.", "Unavailable", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("This time is available!", "Available", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Get the name and time from the textboxes
            string name = textBox3.Text;
            float time = float.Parse(textBox2.Text);  // Ensure this is a valid float value

            // Check if the time is available
            if (IsTimeAvailable(time))
            {
                // Add the appointment if the time is available
                AddAppointment(name, time);
                MessageBox.Show("Appointment added successfully!");
            }
            else
            {
                MessageBox.Show("The selected time is not available.");
            }
        }

        private bool IsTimeAvailable(float checkTime)
        {
            // Use a small tolerance for time range comparison (e.g., 5-minute tolerance)
            float tolerance = 0.05f; // Tolerance of 5 minutes
            float lowerBound = checkTime - tolerance;
            float upperBound = checkTime + tolerance;

            // Check if the time exists in the range
            string checkSql = "SELECT COUNT(*) FROM Appointments WHERE Time BETWEEN @lower AND @upper";
            using (SQLiteCommand cmd = new SQLiteCommand(checkSql, sqliteConnection))
            {
                cmd.Parameters.AddWithValue("@lower", lowerBound);
                cmd.Parameters.AddWithValue("@upper", upperBound);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                return count == 0; // If count is 0, the time is available
            }
        }

        private void AddAppointment(string name, float time)
        {
            // Round the time to the nearest 0.5 or desired precision
            float roundedTime = (float)Math.Round(time, 2);

            // Insert the new appointment into the database
            string insertSql = "INSERT INTO Appointments (Name, Time) VALUES (@Name, @Time)";
            using (SQLiteCommand cmd = new SQLiteCommand(insertSql, sqliteConnection))
            {
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Time", roundedTime);
                cmd.ExecuteNonQuery();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string name = textBox4.Text.Trim(); // Get name from textbox4
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a name.");
                return;
            }

            // Check if the appointment exists for the given name
            string appointmentTime = GetAppointmentTime(name);

            if (appointmentTime == null)
            {
                MessageBox.Show("No appointment found for this name.");
            }
            else
            {
                MessageBox.Show($"Your appointment is scheduled for: {appointmentTime}");
            }
        }

        private string GetAppointmentTime(string name)
        {
            // Query the database for the appointment of the given name
            string query = "SELECT Time FROM Appointments WHERE Name = @Name";

            using (SQLiteCommand cmd = new SQLiteCommand(query, sqliteConnection))
            {
                cmd.Parameters.AddWithValue("@Name", name);

                var result = cmd.ExecuteScalar();
                if (result != null)
                {
                    // If appointment is found, return the time (convert to a string)
                    return result.ToString();
                }
            }
            return null; // Return null if no appointment is found
        }
    }
}
